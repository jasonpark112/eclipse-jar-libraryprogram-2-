package library.dev.application;

public class Books {

    String bookName;
    String category;
    String yesorno;

    Books(String bookName, String category, String yesorno) {
        this.bookName = bookName;
        this.category = category;
        this.yesorno = yesorno;
    }


}
